import java.util.Scanner;

public class oscar {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String nameActor= sc.nextLine();
        double academyPoint=Double.parseDouble(sc.nextLine());
        int numberEvaluators=Integer.parseInt(sc.nextLine());
        double totalPoints=academyPoint;

        for (int i=1; i<=numberEvaluators; i++){
            String nameEvaluator= sc.nextLine();
            double evaluatorsPoints=Double.parseDouble(sc.nextLine());
            evaluatorsPoints=(nameEvaluator.length()*evaluatorsPoints)/2;
            totalPoints=evaluatorsPoints+totalPoints;

        }

        double neededPoints=1250.5-totalPoints;
        if (totalPoints<1250.5) {
            System.out.printf("Sorry, %s you need %.1f more!\n", nameActor, neededPoints);
        }else {
            System.out.printf("Congratulations, %s got a nominee for leading role with %.1f!\n", nameActor, totalPoints);
        }

    }
}
