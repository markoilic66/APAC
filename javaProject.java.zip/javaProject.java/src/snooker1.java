import java.util.Scanner;

public class snooker1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        String stage= sc.nextLine();
        String type= sc.nextLine();
        int numTickets=Integer.parseInt(sc.nextLine());
        char wantPhoto = sc.nextLine().charAt(0);
        double price=0;
        double totalPrice=0;
        switch (stage){
            case "Quarterfinal":
                if (type.equals("Standard")){
                    price=55.5;
                } else if (type.equals("Premium")) {
                    price=105.2;
                } else if (type.equals("VIP")) {
                    price=118.9;
                }
                break;
            case "Semi-final":
                if (type.equals("Standard")){
                    price=75.88;
                } else if (type.equals("Premium")) {
                    price=125.22;
                } else if (type.equals("VIP")) {
                    price=300.4;
                }
                break;
            case "Final":
                if (type.equals("Standard")){
                    price=110.1;
                } else if (type.equals("Premium")) {
                    price=160.66;
                } else if (type.equals("VIP")) {
                    price=400;
                }
                break;
            default:
                System.out.println("Error");
                return;
        }totalPrice=price*numTickets;
        if (wantPhoto=='Y'){
            totalPrice+=40;
        }

        if (totalPrice>=4000){
            totalPrice=totalPrice*0.75;
            if (wantPhoto=='Y'){
                totalPrice-=40;
            }
        } else if (totalPrice>=2500) {
            totalPrice=totalPrice*0.9;
        }

        System.out.println(String.format("%.2f", totalPrice));
    }
}
