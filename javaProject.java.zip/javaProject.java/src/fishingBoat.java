import java.util.Scanner;

public class fishingBoat {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);

        int budget=Integer.parseInt(sc.nextLine());

        String season= sc.nextLine();

        int numberFisherman=Integer.parseInt(sc.nextLine());

        double price=0.00;

        switch (season){
            case "Spring":
                price=3000;
                if (numberFisherman % 2 == 0){
                    price=price*0.95;
                }
                break;
            case "Summer":
                price=4200;
                if (numberFisherman % 2 == 0){
                    price=price*0.95;
                }
                break;
            case "Autumn":
                price=4200;
                break;
            case "Winter":
                price=2600;
                if (numberFisherman % 2 == 0){
                    price=price*0.95;
                }
                break;

                }if (numberFisherman<=6){
            price=price*0.9;
        } else if (numberFisherman>=7 && numberFisherman<=11) {
            price=price*0.85;
        }else {
            price=price*0.75;
        }
        if (budget>=price){
            System.out.printf("Yes! You have %.2f USD left.", budget-price);
        }else {
            System.out.printf("Not enough money! You need %.2f USD.", price-budget);
        }
    }
}
