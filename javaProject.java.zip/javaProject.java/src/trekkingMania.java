import java.util.Scanner;

public class trekkingMania {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int groups = Integer.parseInt(sc.nextLine());

        double climbersFuni = 0, climbersMontBlanc = 0, climbersKilimanjaro = 0, climbersK2 = 0, climbersEverest = 0;
        int totalClimbers = 0;

        for (int i = 1; i <= groups; i++) {
            int numberClimbersPerGroup = Integer.parseInt(sc.nextLine());

            totalClimbers+=numberClimbersPerGroup;
            if (numberClimbersPerGroup <= 5) {

                climbersFuni += numberClimbersPerGroup;

            } else if (numberClimbersPerGroup >= 6 && numberClimbersPerGroup <= 12) {

                climbersMontBlanc += numberClimbersPerGroup;

            } else if (numberClimbersPerGroup >= 13 && numberClimbersPerGroup <= 25) {

                climbersKilimanjaro += numberClimbersPerGroup;

            } else if (numberClimbersPerGroup >= 26 && numberClimbersPerGroup <= 40) {

                climbersK2 += numberClimbersPerGroup;

            } else {

                climbersEverest += numberClimbersPerGroup;

            }
        }
        double funi = (climbersFuni / totalClimbers) * 100;
        double montBlanc = (climbersMontBlanc / totalClimbers) * 100;
        double kilimanjaro = (climbersKilimanjaro / totalClimbers) * 100;
        double k2 = (climbersK2 / totalClimbers) * 100;
        double everest = (climbersEverest / totalClimbers) * 100;

        System.out.printf("%.2f%%\n", funi);
        System.out.printf("%.2f%%\n", montBlanc);
        System.out.printf("%.2f%%\n", kilimanjaro);
        System.out.printf("%.2f%%\n", k2);
        System.out.printf("%.2f%%\n", everest);

    }

}