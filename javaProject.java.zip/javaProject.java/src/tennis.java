import java.util.Scanner;

public class tennis {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int numberTournaments=Integer.parseInt(sc.nextLine());
        int initialPoints=Integer.parseInt(sc.nextLine());
        boolean hasWon=false;
        int totaltPoints=0;
        for (int i=1;i<=numberTournaments;i++){
            int points=0;
            String esitoTorneo= sc.nextLine();
            switch (esitoTorneo){
                case "W":
                    points=2000;
                    hasWon=true;
                break;
                case "F":
                    points=1200;
                break;
                case "SF":
                    points=720;
                    break;
                default:
                    System.out.println("Error");
            }totaltPoints+=points;

        }

        totaltPoints=totaltPoints+initialPoints;

        System.out.printf("Final points: %d\n", totaltPoints);

        int average= (totaltPoints-initialPoints)/numberTournaments;
        System.out.printf("Average points: %d\n", average);





    }
}
