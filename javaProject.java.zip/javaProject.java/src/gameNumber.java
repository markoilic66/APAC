import java.util.Scanner;

public class gameNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String firstPlayer = sc.nextLine();
        String secondPlayer = sc.nextLine();


        if (firstPlayer.equals("End of game") || secondPlayer.equals("End of game")) {
            return;
        }
        int num1=Integer.parseInt(sc.nextLine());
        int num2=Integer.parseInt(sc.nextLine());
    }
}
