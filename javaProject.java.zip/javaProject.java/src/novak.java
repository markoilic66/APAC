import java.util.Scanner;

public class novak {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        double priceRacket=Double.parseDouble(sc.nextLine());
        int numRackets=Integer.parseInt(sc.nextLine());
        int numSneakers=Integer.parseInt(sc.nextLine());

        double totalPriceRackets=(priceRacket*numRackets);
        double priceSneakers=(numSneakers*(priceRacket/6));

        double total=(totalPriceRackets+priceSneakers)*1.2;

        double novak=total/8;
        double sponsor=total-novak;

        int novak1= (int) Math.floor(novak);
        int sponsor1= (int) Math.ceil(sponsor);

        System.out.printf("Price to be paid by Djokovic %d\n", novak1 );
        System.out.printf("Price to be paid by sponsors %d\n", sponsor1);
    }
}
