import java.util.Scanner;

public class flowers {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);

        String flower= sc.nextLine();

        int num=Integer.parseInt(sc.nextLine());

        int budget=Integer.parseInt(sc.nextLine());

        double price=0;



        switch (flower){
            case "Roses":
                price=5;
                if (num>80){
                    price=price*0.9;
                }
                break;
            case "Dahlias":
                price=3.80;
                if (num>90){
                    price=price*0.85;
                }
                break;
            case "Tulips":
                price=2.80;
                if (num>80){
                    price=price*0.85;
                }
                break;
            case "Narcissus":
                price=3;
                if (num<120){
                    price=price*1.15;
                }
                break;
            case "Gladiolus":
                price=2.50;
                if (num<80){
                    price=price*1.2;
                }
                break;
        }
        double result= num*price;
        if (result<=budget){
            System.out.printf("Hey, you have a great garden with %d %s and %.2f USD left.", num, flower, budget-result);
        }else {
            System.out.printf("Not enough money, you need %.2f USD more.", result-budget);
        }




    }
}
