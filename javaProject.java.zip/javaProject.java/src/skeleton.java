import java.util.Scanner;

public class skeleton {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int minutes=Integer.parseInt(sc.nextLine());
        int seconds=Integer.parseInt(sc.nextLine());
        double lengthChute=Double.parseDouble(sc.nextLine());
        int seconds100Meters=Integer.parseInt(sc.nextLine());

        int totalSeconds=minutes*60+seconds;
        double timeDecrease=(lengthChute/120)*2.5;

        double malcolmTime=(lengthChute/100)*seconds100Meters-timeDecrease;
        double neededSeconds=malcolmTime-totalSeconds;

        if (malcolmTime<=totalSeconds){
            System.out.println("Malcolm Davidson won an Olympic quota!");
            System.out.printf("His time is %.3f.", malcolmTime);
        }else {
            System.out.printf("No, Malcolm failed! He was %.3f second slower.", neededSeconds);
        }

    }
}
