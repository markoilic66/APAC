import java.util.Scanner;

public class tradeCommissions {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String city = sc.nextLine();

        double sales = Double.parseDouble(sc.nextLine());

        double result = 0.00;

        switch (city) {
            case "London":
                if (sales >= 0 && sales <= 500) {
                    result = sales * 0.05;
                } else if (sales>500 &&sales<=1000) {
                    result=sales*0.07;
                } else if (sales>1000 && sales<=10000) {
                    result=sales*0.08;
                } else if (sales>10000) {
                    result=sales*0.12;
                }else {
                    System.out.println("error");
                    return;
                }break;
            case "Paris":
                if (sales >= 0 && sales <= 500) {
                    result = sales * 0.045;
                    break;
                } else if (sales>500 &&sales<=1000) {
                    result=sales*0.075;
                } else if (sales>1000 && sales<=10000) {
                    result=sales*0.1;
                } else if (sales>10000) {
                    result=sales*0.13;
                }else {
                    System.out.println("error");
                    return;
                }break;
            case "Rome":
                if (sales >= 0 && sales <= 500) {
                    result = sales * 0.055;
                    break;
                } else if (sales>500 &&sales<=1000) {
                    result=sales*0.08;
                } else if (sales>1000 && sales<=10000) {
                    result=sales*0.12;
                } else if (sales>10000) {
                    result=sales*0.145;
                }else {
                    System.out.println("error");
                    return;
                }break;

            default:
                System.out.println("error");
                return;

        }
        if (result > 0.00) {


        }
        System.out.printf("%.2f%n", result);
    }
}
