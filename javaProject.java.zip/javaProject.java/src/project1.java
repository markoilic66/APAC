import java.util.Scanner;

public class project1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       int sati;
       int minuti;
       for (sati=0; sati<24; sati++ ){
           System.out.printf(" %d",sati);
       for (minuti=0; minuti<60; minuti++);
        System.out.printf(" %02d:%02d\n", sati, minuti);}

    }

            }


