import java.util.Scanner;

public class cleverLily {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);

        int age=Integer.parseInt(sc.nextLine());
        double priceWashingMachine=Double.parseDouble(sc.nextLine());
        int toy=Integer.parseInt(sc.nextLine());
        int i;
        double saving=0;


        for (i=0; i<=age; i++){
            if (i%2==0){
                saving+=10*(i/2);

            }

        }saving=saving-(age/2);
        System.out.printf("%.2f", saving);
        }
    }

