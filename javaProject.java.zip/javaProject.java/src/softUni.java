import java.util.Scanner;

public class softUni {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int i;
        int n=Integer.parseInt(sc.nextLine());
        for (i=n; i>=-5; i-- ){
            System.out.println(i);
        }
    }
}
