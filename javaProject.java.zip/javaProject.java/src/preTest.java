import java.util.Scanner;

public class preTest {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        double meter=Double.parseDouble(sc.nextLine());
        double totalPrice=meter*7.61;
        totalPrice=totalPrice*0.82;
        double discount=totalPrice*0.18;
        System.out.printf("The final price is: %.2f USD.\n", totalPrice);
        System.out.printf("The discount is %.2f",discount );


        }
    }

