import java.util.Scanner;

public class numberGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String firstPlayerName = scanner.nextLine();
        String secondPlayerName = scanner.nextLine();

        int firstPlayerPoints = 0;
        int secondPlayerPoints = 0;

        while (true) {
            int firstPlayerCard = Integer.parseInt(scanner.nextLine());
            int secondPlayerCard = Integer.parseInt(scanner.nextLine());

            if (firstPlayerCard > secondPlayerCard) {
                firstPlayerPoints += firstPlayerCard - secondPlayerCard;
            } else if (secondPlayerCard > firstPlayerCard) {
                secondPlayerPoints += secondPlayerCard - firstPlayerCard;
            } else { // Number war
                System.out.println("Number wars!");

                int firstPlayerExtraCard = Integer.parseInt(scanner.nextLine());
                int secondPlayerExtraCard = Integer.parseInt(scanner.nextLine());

                if (firstPlayerExtraCard > secondPlayerExtraCard) {
                    System.out.printf("%s is winner with %d points", firstPlayerName, firstPlayerPoints);
                    return;
                } else if (secondPlayerExtraCard > firstPlayerExtraCard) {
                    System.out.printf("%s is winner with %d points", secondPlayerName, secondPlayerPoints);
                    return;
                }
            }

            String command = scanner.nextLine();
            if (command.equals("End of game")) {
                break;
            }
        }

        System.out.printf("%s has %d points\n", firstPlayerName, firstPlayerPoints);
        System.out.printf("%s has %d points", secondPlayerName, secondPlayerPoints);
    }
}