import java.util.Scanner;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class agencija {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Inserisci l'username: ");
        String username = input.nextLine();
        System.out.print("Inserisci la password: ");
        String password = input.nextLine();

        // Verifica username e password
        if (username.equals("Lunalux") && password.equals("Lunalux1!")
                || username.equals("Stravel") && password.equals("Stravel2\"")
                || username.equals("BigStarTravel") && password.equals("BigStarTravel3£")) {

            System.out.println("Accesso consentito!");

            // Inserimento date di arrivo e partenza
            System.out.print("Inserisci la data di arrivo (yyyy-mm-dd): ");
            LocalDate dataArrivo = LocalDate.parse(input.nextLine());
            System.out.print("Inserisci la data di partenza (yyyy-mm-dd): ");
            LocalDate dataPartenza = LocalDate.parse(input.nextLine());

            // Calcolo numero di giorni di parcheggio
            long giorniParcheggio = ChronoUnit.DAYS.between(dataArrivo, dataPartenza);

            // Scelta del parcheggio
            System.out.println("Scegli il parcheggio:");
            System.out.println("p11: 300 dinari al giorno se il soggiorno dura fino a 10 giorni, "
                    + "200 dinari al giorno se il soggiorno dura da 10 a 30 giorni, "
                    + "100 dinari al giorno se il soggiorna più di 30 giorni");
            System.out.println("g: 500 dinari al giorno sempre");
            System.out.println("p3: 300 dinari al giorno sempre");
            System.out.println("p7: 350 dinari al giorno sempre");

            String parcheggio = input.nextLine();
            double prezzoGiornaliero = 0;

            // Calcolo prezzo giornaliero del parcheggio scelto
            switch (parcheggio) {
                case "p11":
                    if (giorniParcheggio <= 10) {
                        prezzoGiornaliero = 300;
                    } else if (giorniParcheggio <= 30) {
                        prezzoGiornaliero = 200;
                    } else {
                        prezzoGiornaliero = 100;
                    }
                    break;
                case "g":
                    prezzoGiornaliero = 500;
                    break;
                case "p3":
                    prezzoGiornaliero = 300;
                    break;
                case "p7":
                    prezzoGiornaliero = 350;
                    break;
                default:
                    System.out.println("Parcheggio non valido!");
                    System.exit(0);
            }

            // Calcolo prezzo totale del parcheggio
            double prezzoTotale = prezzoGiornaliero * giorniParcheggio;
            System.out.println("Il prezzo totale per il parcheggio scelto è di " + prezzoTotale + " dinari.");

        } else {
            System.out.println("Accesso negato!");
        }

        input.close();
    }
}