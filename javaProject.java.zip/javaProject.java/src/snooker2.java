import java.util.Scanner;

public class snooker2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Read input from console
        String stage = sc.nextLine();
        String ticketType = sc.nextLine();
        int numTickets = Integer.parseInt(sc.nextLine());
        char wantsPhoto = sc.nextLine().charAt(0);

        // Calculate ticket price based on stage and ticket type
        double ticketPrice = 0.0;
        switch (stage) {
            case "Quarterfinal":
                switch (ticketType) {
                    case "Standard":
                        ticketPrice = 55.50;
                        break;
                    case "Premium":
                        ticketPrice = 105.20;
                        break;
                    case "VIP":
                        ticketPrice = 118.90;
                        break;
                    default:
                        System.out.println("Invalid ticket type.");
                        return;
                }
                break;
            case "Semi-final":
                switch (ticketType) {
                    case "Standard":
                        ticketPrice = 75.88;
                        break;
                    case "Premium":
                        ticketPrice = 125.22;
                        break;
                    case "VIP":
                        ticketPrice = 300.40;
                        break;
                    default:
                        System.out.println("Invalid ticket type.");
                        return;
                }
                break;
            case "Final":
                switch (ticketType) {
                    case "Standard":
                        ticketPrice = 110.10;
                        break;
                    case "Premium":
                        ticketPrice = 160.66;
                        break;
                    case "VIP":
                        ticketPrice = 400.0;
                        break;
                    default:
                        System.out.println("Invalid ticket type.");
                        return;
                }
                break;
            default:
                System.out.println("Invalid stage.");
                return;
        }

        // Calculate total price including photo option
        double totalPrice = ticketPrice * numTickets;
        if (wantsPhoto == 'Y') {
            totalPrice += 40.0;
        }

        // Apply discounts based on total price
        if (totalPrice >= 4000.0) {
            totalPrice *= 0.75;
            if (wantsPhoto == 'Y') {
                totalPrice -= 40.0;
            }
        } else if (totalPrice >= 2500.0) {
            totalPrice *= 0.9;
        }

        // Print total price formatted to two decimal places
        System.out.printf("%.2f", totalPrice);
    }
}
