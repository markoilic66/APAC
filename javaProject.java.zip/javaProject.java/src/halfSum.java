import java.util.Scanner;

public class halfSum {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int num=Integer.parseInt(sc.nextLine());

        int [] arr= new int[num];
        int sum=0, max=Integer.MIN_VALUE;

        for (int i=0; i<num; i++){
            arr[i]= sc.nextInt();
            sum+=arr[i];
            max=Math.max(max, arr[i]);

            }
            int diff=Math.abs(sum-2*max);
        boolean found=false;

        for (int i=0; i<num; i++){
            if (arr[i]==sum-arr[i]){
                System.out.println("Yes");
                System.out.println("Sum = "+arr[i]);
                found=true;
                break;

            }
        }
        if (!found){
            System.out.println("No");
            System.out.println("Diff = "+diff);
        }sc.close();
    }
}
