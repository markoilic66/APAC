import java.util.Scanner;

public class skiTrip {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
         int days=Integer.parseInt(sc.nextLine());
         String type= sc.nextLine();
         String assessment= sc.nextLine();
         int nights=days-1;
         double cost=-1;

         switch (type){
             case "room for one person":
                 cost=nights*18;
                 break;
             case "apartment":
                 cost=nights*25;
                 if (days<10){
                     cost=cost*0.7;
                 } else if (days>=10 && days<=15) {
                 cost=cost*0.65;
                 }else {
                 cost=cost*0.5;
                 }
                 break;
             case "president apartment":
                 cost=nights*35;
                 if (days<10){
                 cost=cost*0.9;
                 } else if (days>=10 && days<=15) {
                 cost=cost*0.85;
                 }else {
                     cost=cost*0.8;
                 }
                 break;
         }
        if (assessment.equals("positive")){
            cost=cost*1.25;
        }else {
            cost=cost*0.9;
        }
        System.out.printf("%.2f", cost);


    }
}
