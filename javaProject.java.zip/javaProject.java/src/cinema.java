import java.util.Scanner;

public class cinema {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        String projection= sc.nextLine();

        int rows=Integer.parseInt(sc.nextLine());

        int colums=Integer.parseInt(sc.nextLine());
        
        double income=0.00;

        if ("Premiere".equals(projection)){
            income= rows*colums*12;
        } else if ("Normal".equals(projection)) {
            income= rows*colums*7.5;
        } else if ("Discount".equals(projection)) {
            income= rows*colums*5;
        }System.out.printf("%.2f", income);
    }
}
