import java.util.Scanner;

public class highJump {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int targetHeight = scanner.nextInt();
        int currentHeight = targetHeight - 30;
        int jumps = 0;
        int consecutiveFails = 0;
        while (true) {
            int jumpHeight = scanner.nextInt();
            jumps++;
            if (jumpHeight > currentHeight) {
                currentHeight += 5;
                consecutiveFails = 0;
                if (currentHeight > targetHeight) {
                    System.out.printf("Jim succeeded, he jumped over %dcm after %d jumps.", currentHeight - 5, jumps);
                    break;
                }
            } else {
                consecutiveFails++;
                if (consecutiveFails == 3) {
                    System.out.printf("Jim failed at %dcm after %d jumps.", currentHeight, jumps);
                    break;
                }
            }
        }
    }
}
