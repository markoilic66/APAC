import java.util.Scanner;

public class istogram {
    public static void main(String[] args) {

        Scanner sc= new Scanner(System.in);
        int n= sc.nextInt();
        int below200=0, range200_399=0, range400_599=0, range600_799=0, above800=0;




        for (int i=0; i<n; i++){
           int num= sc.nextInt();
            if (num<200){
                below200++;
            } else if (num<400) {
                range200_399++;
            } else if (num<600) {
                range400_599++;
            } else if (num<800) {
                range600_799++;
            }else {
                above800++;
            }
        }
        double p1=(double) below200/n*100;
        double p2=(double) range200_399/n*100;
        double p3=(double) range400_599/n*100;
        double p4=(double) range600_799/n*100;
        double p5=(double) above800/n*100;

        System.out.printf("%.2f%%\n", p1);
        System.out.printf("%.2f%%\n", p2);
        System.out.printf("%.2f%%\n", p3);
        System.out.printf("%.2f%%\n", p4);
        System.out.printf("%.2f%%\n", p5);
    }
}
