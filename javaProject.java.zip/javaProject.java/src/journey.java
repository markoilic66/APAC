import java.util.Scanner;

public class journey {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        double budget=Double.parseDouble(sc.nextLine());

        String godisnjeDoba= sc.nextLine();

        String lokacija="";

        String vrstaSmestaja="";

        double trosak=-1;

        if (budget<=100){
            lokacija="Serbia";
            if (godisnjeDoba.equals("summer")){
                vrstaSmestaja="Camp";
                trosak=budget*0.30;
            } else if (godisnjeDoba.equals("winter")) {
                vrstaSmestaja="Hotel";
                trosak=budget*0.70;
            }
            } else if (budget<=1000){
            lokacija="Europe";
            vrstaSmestaja="Hotel";
            if (godisnjeDoba.equals("summer")){
                trosak=budget*0.40;
            } else if (godisnjeDoba.equals("winter")) {
                trosak=budget*0.80;
            }
            } else  {
            lokacija= "USA";
            trosak = budget * 0.90;
            if (godisnjeDoba.equals("summer")) {
vrstaSmestaja="Camp";

            } else if (godisnjeDoba.equals("winter")) {
vrstaSmestaja="Hotel";

            }

        }

        System.out.printf("Somewhere in %s\n", lokacija);
        System.out.printf("%s - %.2f\n", vrstaSmestaja, trosak);
        }
        }


