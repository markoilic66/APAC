import java.util.Scanner;

public class snooker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String stage = sc.nextLine();
        String type = sc.nextLine();
        int numTickets = Integer.parseInt(sc.nextLine());
        char wantPhoto = sc.nextLine().charAt(0);
        double price = 0.0;
        double totalPrice = 0.0;

        switch (stage) {
            case "Quarter final":
                if (type.equals("Standard")) {
                    price = 55.5;
                } else if (type.equals("Premium")) {
                    price = 105.2;
                } else if (type.equals("VIP")) {
                    price = 118.9;
                }
                break;
            case "Semi final":
                if (type.equals("Standard")) {
                    price = 75.88;
                } else if (type.equals("Premium")) {
                    price = 125.22;
                } else if (type.equals("VIP")) {
                    price = 300.4;
                }
                break;
            case "Final":
                if (type.equals("Standard")) {
                    price = 110.1;
                } else if (type.equals("Premium")) {
                    price = 160.66;
                } else if (type.equals("VIP")) {
                    price = 400;
                }
                break;

        }
        totalPrice = price * numTickets;
        if (totalPrice<2500) {
            if (wantPhoto == 'Y') {
                totalPrice = totalPrice + (40 * numTickets);
            }
        } else if (totalPrice >= 2500 && totalPrice<4000) {
            totalPrice = totalPrice * 0.9;
            if (wantPhoto=='Y'){
                totalPrice=totalPrice+(40*numTickets);
            }
        }else {
            totalPrice=totalPrice*0.75;
        }
        System.out.printf("%.2f", totalPrice);

    }
}