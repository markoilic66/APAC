import java.util.Scanner;

public class operations {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int prvi= Integer.parseInt(sc.nextLine());

        int drugi= Integer.parseInt(sc.nextLine());

        String operation= sc.nextLine();

        int rezultatOperacije=-1;

        switch (operation){
            case "+":
                rezultatOperacije=prvi+drugi;
                if (rezultatOperacije%2==0){
                    System.out.printf("%d %s %d = %d - even", prvi, operation, drugi, rezultatOperacije);
                }else {
                    System.out.printf("%d %s %d = %d - odd", prvi, operation, drugi, rezultatOperacije);
                }

                break;
            case "-":
                rezultatOperacije=prvi-drugi;
                if (rezultatOperacije%2==0){
                    System.out.printf("%d %s %d = %d - even", prvi, operation, drugi, rezultatOperacije);
                }else {
                    System.out.printf("%d %s %d = %d - odd", prvi, operation, drugi, rezultatOperacije);
                }
                break;
            case "*":
                rezultatOperacije=prvi*drugi;
                if (rezultatOperacije%2==0){
                    System.out.printf("%d %s %d = %d - even", prvi, operation, drugi, rezultatOperacije);
                }else {
                    System.out.printf("%d %s %d = %d - odd", prvi, operation, drugi, rezultatOperacije);
                }
                break;
            case "/":
                if (drugi==0){
                    System.out.printf("Cannot divide %d by zero", prvi);
                    return;
                }double decimalanRezultatDeljenja=(double) prvi/drugi;
                System.out.printf("%d / %d = %.2f",prvi, drugi, decimalanRezultatDeljenja);
                break;
            case "%":
                if (drugi==0){
                System.out.printf("Cannot divide %d by zero", prvi);
                return;
            } int ostatak= prvi%drugi;
                System.out.printf("%d %% %d = %d", prvi, drugi, ostatak);
                break;
            default:
                System.out.println("Error");
                return;
        }



    }
}
