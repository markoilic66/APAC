import java.util.Scanner;

public class fitness {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numVisitors = scanner.nextInt();
        scanner.nextLine();

        int backCount = 0;
        int chestCount = 0;
        int legsCount = 0;
        int absCount = 0;
        int shakeCount = 0;
        int barCount = 0;

        for (int i = 0; i < numVisitors; i++) {
            String activity = scanner.nextLine();

            switch (activity) {
                case "Back":
                    backCount++;
                    break;
                case "Chest":
                    chestCount++;
                    break;
                case "Legs":
                    legsCount++;
                    break;
                case "Abs":
                    absCount++;
                    break;
                case "Protein shake":
                    shakeCount++;
                    break;
                case "Protein bar":
                    barCount++;
                    break;
            }
        }

        double workoutPercentage = (double)(backCount + chestCount + legsCount + absCount) / numVisitors * 100;
        double proteinPercentage = (double)(shakeCount + barCount) / numVisitors * 100;

        System.out.println(backCount + " - back");
        System.out.println(chestCount + " - chest");
        System.out.println(legsCount + " - legs");
        System.out.println(absCount + " - abs");
        System.out.println(shakeCount + " - protein shake");
        System.out.println(barCount + " - protein bar");
        System.out.printf("%.2f%% - work out\n", workoutPercentage);
        System.out.printf("%.2f%% - protein\n", proteinPercentage);
    }
}