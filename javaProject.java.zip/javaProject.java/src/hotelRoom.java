import java.util.Scanner;

public class hotelRoom {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);

        String month= sc.nextLine();

        int nights=Integer.parseInt(sc.nextLine());

        double priceApartment=0.00;
        double priceStudio=0.00;



        if (month.equals("May") || month.equals("Oktober")){
            priceApartment= nights*65;
            priceStudio= nights*50;
            if (nights>7 && nights<=14){
                priceStudio=priceStudio*0.95;
            } else if (nights>14) {
                priceStudio=priceStudio*0.70;
            }
        } else if (month.equals("June") || month.equals("Septembar")) {
            priceApartment= nights*68.70;
            priceStudio= nights*75.20;
            if (nights>14){
                priceStudio=priceStudio*0.8;
            }
        } else if (month.equals("Julu") || month.equals("August")) {
            priceApartment=nights*77;
            priceStudio=nights*76;
        }if (nights>14){
            priceApartment=priceApartment*0.9;

    }
        System.out.printf("Apartment: %.2f USD.\nStudio: %.2f USD.", priceApartment, priceStudio);
    }
}
