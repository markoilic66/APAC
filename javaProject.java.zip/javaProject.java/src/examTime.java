import java.util.Scanner;

public class examTime {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int hourStart=Integer.parseInt(sc.nextLine());
        int minuteStart=Integer.parseInt(sc.nextLine());
        int hourArrive=Integer.parseInt(sc.nextLine());
        int minuteArrive=Integer.parseInt(sc.nextLine());


        int examTime= hourStart*60+minuteStart;
        int arrivalTime= hourArrive*60+minuteArrive;
        int diff=arrivalTime-examTime;

        if (diff>0){
            System.out.println("Late\n");
            if (diff>=60){
                System.out.printf("%d:%02d hours after the start\n", diff/60, diff%60);
            }else{
                System.out.printf("%d minutes after the start\n", diff);
            }
        } else if (diff>=-30) {
            System.out.println("On time");
            if (diff !=0){
                System.out.printf("%d minutes before the start\n", -diff);
            }
        }else {
            System.out.println("Early\n");
            if (diff<=-60){
                System.out.printf("%d:%02d hours before the start", -diff/60, -diff%60);
            }else {
                System.out.printf("%d minutes before the start", -diff);
            }
        }


    }
}
